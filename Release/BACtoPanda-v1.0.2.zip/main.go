package main

import (
	"fmt"
	"log"
	"os"
)

func main() {
	FlagParse()

	for _, path := range sourceDir {
		pools, err := os.ReadDir(path)
		if err != nil {
			log.Fatal(err)
		}
		for _, pool := range pools {
			//reads, err := os.ReadDir(path + "/" + pool.Name())
			//if err != nil {
			//	log.Fatal(err)
			//}
			//for _, read := range reads {
			if pool.Name()[:2] == "SP" {
				samplePath := path + "/" + pool.Name()
				runBowtie2(samplePath)            //Bowtie2
				runSamtools(samplePath)           //Samtools
				calculatePotentialBAC(samplePath) //DepthCalling
				//}
			}
		}
	}
	// Assignment
	r, num := location()
	file, err := os.Create(string(destinationDir) + "/assignment/SP01_BAC.bed")
	defer file.Close()
	if err != nil {
		log.Fatal(err)
	}
	file.WriteString(fmt.Sprintf("%s", r))
	fmt.Printf("There are %d BAC parsed succussfully", num)

}
