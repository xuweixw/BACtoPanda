package main

import (
	"bufio"
	"fmt"
	"log"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

//const border float64 = 3000

type Region struct {
	name       string
	chr        string
	start, end int64
}

func (r Region) String() string {
	return fmt.Sprintf("%s\t%d\t%d\t%s\n", r.chr, r.start, r.end, r.name)
}

// Equal method determines two Regions that are completely or extremely same.
// constant "border" defines the difference.
func (r Region) Equal(ele Region) (*Region, bool) {
	if r.chr == ele.chr {
		if math.Abs(float64(r.start-ele.start)) <= border && math.Abs(float64(r.end-ele.end)) <= border {
			var start, end int64
			if r.start > ele.start {
				start = ele.start
			} else {
				start = r.start
			}
			if r.end > ele.end {
				end = r.end
			} else {
				end = ele.end
			}
			r.start = start
			r.end = end
			return &r, true
		}
	}
	return nil, false
}

type RegionSet struct {
	regions []Region
}

// InitRegionSet function initialize RegionSet.
func InitRegionSet() *RegionSet {
	var rs RegionSet
	rs.regions = make([]Region, 0)
	return &rs
}
func (rs RegionSet) String() string {
	str := strings.Builder{}
	for _, item := range rs.regions {
		str.WriteString(fmt.Sprintf("%s", item))
	}
	return str.String()
}

func Intersection(a, b *RegionSet) *RegionSet {
	var set = RegionSet{regions: make([]Region, 0)}
	for _, av := range a.regions {
		for _, bv := range b.regions {
			if r, ok := av.Equal(bv); ok {
				set.regions = append(set.regions, *r)
			}
		}
	}
	return &set
}

func NewRegionSet(filePath string) *RegionSet {
	var set = InitRegionSet()
	file, err := os.Open(filePath)
	defer file.Close()
	if err != nil {
		log.Fatalln("Open file Error: ", err)
	}
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		record := strings.Split(scanner.Text(), "\t")
		chr := record[0]
		start, _ := strconv.ParseInt(record[1], 10, 64)
		end, _ := strconv.ParseInt(record[2], 10, 64)
		r := Region{chr: chr, start: start, end: end}
		set.regions = append(set.regions, r)
	}
	return set
}

func testIntersection() {
	//Hic_asm_0	12555930	12665226
	//Hic_asm_0	20211144	20317010
	//Hic_asm_0	22495321	22609245
	//Hic_asm_0	24960826	25077423
	//Hic_asm_0	41105250	41209022
	r1 := Region{chr: "Hic_asm_1", start: 12555930, end: 12665226}
	r2 := Region{chr: "Hic_asm_0", start: 20211144, end: 20317010}
	r3 := Region{chr: "Hic_asm_1", start: 22495321, end: 22609245}
	r4 := Region{chr: "Hic_asm_0", start: 24960826, end: 25077423}
	r5 := Region{chr: "Hic_asm_0", start: 41105250, end: 41209022}
	set1 := RegionSet{regions: []Region{r1, r2, r3}}
	set2 := RegionSet{regions: []Region{r3, r4, r5, r1}}
	fmt.Printf("%v", Intersection(&set1, &set2))
}

func location() (*RegionSet, int) {
	var rowID = map[string][]int{"A": {8, 12}, "B": {8, 13}, "C": {8, 14}, "D": {8, 15},
		"E": {9, 12}, "F": {9, 13}, "G": {9, 14}, "H": {9, 15},
		"I": {10, 12}, "J": {10, 13}, "K": {10, 14}, "L": {10, 15},
		"M": {11, 12}, "N": {11, 13}, "O": {11, 14}, "P": {11, 15}}
	var colID = map[string][]int{"01": {16, 21}, "02": {16, 22}, "03": {16, 23}, "04": {16, 24}, "05": {16, 25},
		"06": {17, 21}, "07": {17, 22}, "08": {17, 23}, "09": {17, 24}, "10": {17, 25},
		"11": {18, 21}, "12": {18, 22}, "13": {18, 23}, "14": {18, 24}, "15": {18, 25},
		"16": {19, 21}, "17": {19, 22}, "18": {19, 23}, "19": {19, 24}, "20": {19, 25},
		"21": {20, 21}, "22": {20, 22}, "23": {20, 23}, "24": {20, 24}}

	var rowMap = make(map[string]*RegionSet, 16)
	var colMap = make(map[string]*RegionSet, 24)
	var poolMap = make(map[int]*RegionSet, 25)
	var results = InitRegionSet()
	var num int
	for i := 1; i <= 25; i++ {
		poolMap[i] = NewRegionSet(fmt.Sprintf(string(destinationDir)+"/depthCalling/SP01-%02d_BAC.bed", i))
	}
	for k, v := range rowID {
		rowMap[k] = Intersection(poolMap[v[0]], poolMap[v[1]])
	}
	for k, v := range colID {
		colMap[k] = Intersection(poolMap[v[0]], poolMap[v[1]])
	}

	for p := 1; p <= 7; p++ {
		for r, _ := range rowID {
			for c, _ := range colID {
				BACID := fmt.Sprintf("%03d%s%s", p, r, c)
				plate := Intersection(rowMap[r], colMap[c])
				well := Intersection(poolMap[p], plate)
				if len(well.regions) == 0 {
					num++
					//fmt.Println(BACID)
					//fmt.Println("plate: ", plate)
					//fmt.Println("well: ", well)
				} else {
					for i, _ := range well.regions {
						well.regions[i].name = BACID
						results.regions = append(results.regions, well.regions[i])
					}
				}
			}
		}
	}
	sort.Slice(results.regions, func(i, j int) bool { return results.regions[i].chr < results.regions[j].chr })
	return results, num
}

var border float64 = 0

func testBorder() {
	n := 150
	for i := 1; i <= 100; i++ {
		border = float64(n * i)
		_, n := location()
		fmt.Printf("%.0f\t%d\n", border, n)
	}
}

func assignment() {
	// Assignment
	r, num := location()
	file, err := os.Create(string(destinationDir) + "/assignment/SP01_BAC.bed")
	defer file.Close()
	if err != nil {
		log.Fatal(err)
	}
	if _, err := file.WriteString(fmt.Sprintf("%s", r)); err != nil {
		log.Printf("rncounter an issue in writing : %s ", err)
	} else {
		log.Printf("There are %d BAC parsed succussfully", num)
	}

}
