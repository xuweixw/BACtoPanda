package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"testing"
)

func TestWhat(t *testing.T) {
	file, err := os.Open("./test-data/BAC-40-1.depth.tab")
	if err != nil {
		log.Fatalf("open file error: %v", err)
	}
	output := NewTiles(file)

	for _, item := range output.Splite(1000) {
		if item.potentialBAC() {
			fmt.Printf("%v", item.ToBed())
		}
	}
}

func TestCommand(t *testing.T) {
	var (
		input = flag.String("input", "", "depth.tab file")
		help  = flag.Bool("help", false, "help usage")
	)
	flag.Parse()
	if *help == true {
		flag.Usage()
		os.Exit(0)
	}
	file, err := os.Open(*input)
	defer file.Close()
	if err != nil {
		log.Fatalf("open file error: %v", err)
	}
	output := NewTiles(file)

	for _, item := range output.Splite(1000) {
		if item.potentialBAC() {
			fmt.Printf("%v", item.ToBed())
		}
	}
}
