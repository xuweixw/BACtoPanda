package main

import (
	// "flag"
	"fmt"
	"github.com/biogo/biogo/alphabet"
	"github.com/biogo/biogo/io/seqio"
	"github.com/biogo/biogo/io/seqio/fasta"
	"github.com/biogo/biogo/io/seqio/fastq"
	"github.com/biogo/biogo/seq/linear"
	"log"
	"os"
	"regexp"
	"sort"
	"sync"
)

// struct array for scores
//
//	Substitution matrix
//		s(a, b) if a == b, s=1, else s = 0, gap (-1)
//	Initialization
//		F(i, 0) = 0
//		F(0, j)	= 0
//	Iteration F(i, j) = max(F(i, j-1)-d, F(i-1, j)-d, F(i-1, j-1) -d)
//

type scoreMatrix struct {
	data []int
	row, col int
}

func initialScore(seqA_len, seqB_len int) scoreMatrix {
	row := seqA_len +1
	col := seqB_len +1
	length := row * col
	s := make([]int,length, length)
	return scoreMatrix{s, row,col}
}

func (sm scoreMatrix) string() (str string) {
	for r :=0 ;r < sm.row; r++{
		for c := 0; c < sm.col; c++{
			str += fmt.Sprintf("%3d", sm.data[r * sm.col + c])
		}
		str += fmt.Sprintf("\n")
	}
	return
}

func (sm *scoreMatrix) setElement(row, col, value int) {
	location := row * sm.col + col
	sm.data[location] = value
}

func (sm *scoreMatrix) getElement(row, col int) int {
	location := row * sm.col + col
	return sm.data[location]
}
func (sm *scoreMatrix) lastCol() (l []int){
	for r := 0; r< sm.row; r++{
		loc := (r + 1) * sm.col - 1
		l = append(l, sm.data[loc])
	}
	return
}
func (sm *scoreMatrix) lastRow() (r []int){
	for l := 0; l < sm.col; l++{
		r = append(r, sm.data[(sm.row -1) * sm.col + l])
	}
	return
}

// create a func to alignment of two DNA strings

// IsOverlap
// semi-global alignment
//	a refers to BAC vector end sequences
//	b refers to a NGS read
func IsOverlap(a, b string, min, edit int) (bool bool){
	var scoring int
	score := initialScore(len(a), len(b))
	for i := 0; i< len(a); i++{
		for j := 0; j < len(b); j++{
			// 比对分
			if a[i] == b[j]{
				scoring = 1
			} else {
				scoring = -1
			}
			// 打分记录
			threeMax := []int{
				score.getElement(i, j) + scoring,
				score.getElement(i+1, j)  -1,
				score.getElement(i, j+1)  -1,
			}
			sort.Ints(threeMax)
			score.setElement(i + 1, j + 1, threeMax[2])
		}
	}

	var indexMaxvalue, maxValue int
	for i, v := range score.lastRow(){
		if i == 0 || v > maxValue{
			indexMaxvalue = i
			maxValue = v
		}
	}
	if maxValue > min && indexMaxvalue- maxValue  <= edit{
		bool = true
	}
	return
}

// 计算反向互补序列
func reverseComplement(s string) (rc string) {
	base := map[byte]byte{
		'A':'T',
		'T':'A',
		'G':'C',
		'C':'G',
	}
	n := len(s)
	var bs []byte
	for i := n-1; i>= 0; i-- {
		bs = append(bs, base[byte(s[i])])
	}
	rc = string(bs)
	return
}


type PEReads struct{
	R1, R2 *linear.Seq
	overlap bool
}
func (p PEReads) isOverlapping(VES string, min, edit int) bool{
	R1Forward := p.R1.Seq.String()
	R1RevereComp := reverseComplement(R1Forward)

	R2Forward := p.R2.Seq.String()
	R2ReverseComp := reverseComplement(R2Forward)

	seq := VES[len(VES)-18:len(VES)]
	seed, _ := regexp.Compile(seq)
	var firstRound bool
	//var blankSlice = []string{}
	if n := seed.FindStringSubmatch(R1Forward); len(n) != 0{
		firstRound = true
	} else if n := seed.FindStringSubmatch(R1RevereComp); len(n) != 0{
		firstRound = true
	} else if n := seed.FindStringSubmatch(R2Forward); len(n) != 0{
		firstRound = true
	} else if n := seed.FindStringSubmatch(R2ReverseComp); len(n) != 0{
		firstRound = true
	} else {
		return false
	}

	if firstRound == true && IsOverlap(VES, R1Forward, min, edit){
		return true
	} else if IsOverlap(VES, R1RevereComp, min, edit){
		return true
	} else if IsOverlap(VES, R2Forward, min, edit){
		return true
	} else if IsOverlap(VES, R2ReverseComp, min, edit){
		return true
	} else{
		return false
	}
}
func (p PEReads) Writer(writer *fasta.Writer){
	if _, err := writer.Write(p.R1); err != nil {
		log.Fatal(err)
	}
	if _, err := writer.Write(p.R2); err != nil{
		log.Fatal(err)
	}
}

var jobChan = make(chan PEReads, 1000)
var resultChan = make(chan PEReads, 10)
var wg sync.WaitGroup

func worker(in <-chan PEReads, out chan<- PEReads, VES string, min, edit int){
	defer wg.Done()
	blankPEReads := PEReads{nil,nil,false}
	for {
		job, ok := <- in
		if !ok {
			break
		}
		if job == blankPEReads {
			continue
		}
		if job.isOverlapping(VES, min, edit){
			job.overlap = true
			out <- job
		}
	}
	//results <- blank_PEReads
}

// ReadPRFastq function read paried-end reads into jobs channel.
// R1 and R2 arguments represent the path of R1 and R2 reads.
func ReadPEFastq(jobs chan<- PEReads, R1, R2 string) {
	defer wg.Done()
	t := linear.NewSeq("", nil, alphabet.DNA)

	R1_file, _ := os.Open(R1)
	defer R1_file.Close()
	R2_file, _ := os.Open(R2)
	defer R2_file.Close()

	R1_fq := fastq.NewReader(R1_file, t)
	R2_fq := fastq.NewReader(R2_file, t)

	R1_sc := seqio.NewScanner(R1_fq)
	R2_sc := seqio.NewScanner(R2_fq)
	var count int
	for {
		R1_bool := R1_sc.Next()
		R2_bool := R2_sc.Next()
		if R1_bool == false || R2_bool == false {
			break
		}
		curr_PEReads :=  PEReads{R1:R1_sc.Seq().(*linear.Seq),
			R2: R2_sc.Seq().(*linear.Seq),
			overlap: false}
		jobs <- curr_PEReads
		count ++
		fmt.Printf("%10d reads has been calculated\r",count)
	}
	close(jobs)
}

/*
>pIndigoBAC536-S-forward
TCTTCGCTATTACGCCAGCTGGCGAAAGGGGGATGTGCTGCAAGGCGATTAAGTTGGGTAACGCCAGGGTTTTC
CCAGTCACGACGTTGTAAAACGACGGCCAGTGAATTGTAATACGACTCACTATAGGGCGAATTCGAGCTCGGTA
CCCGGGGATCCTCTAGAGTCGACCTGCAGGCATGC
*/

//var (
//	R1_file = flag.String("R1","", "NGS R1 reads file path")
//	R2_file = flag.String("R2","", "NGS R2 reads file path")
//	out_file = flag.String("out","", "target R1 and R2 has been merged in a fasta format file")
//	VES_seq = flag.String("ves","", "BAC vector end sequence, about 150 bp")
//	min_overlap = flag.Int("min", 20, "the min overlapping")
//	edit = flag.Int("edit", 1, "eidt distance")
//	help = flag.Bool("help", false, "the help document")
//)

// The two vector end sequence of pIndigoBAC536-S are long 158 bp and 150 bp, respectively.
const (
	VESF = "TGCTGCAAGGCGATTAAGTTGGGTAACGCCAGGGTTTTCCCAGTCACGACGTTGTAAAAC" +
		"GACGGCCAGTGAATTGTAATACGACTCACTATAGGGCGAATTCGAGCTCGGTACCCGGGG" +
		"ATCCTCTAGAGTCGACCTGCAGGCATGC"
	VESR = "AGTTAGCTCACTCATTAGGCACCCCAGGCTTTACACTTTATGCTTCCGGCTCGTATGTTG" +
		"TGTGGAATTGTGAGCGGATAACAATTTCACACAGGAAACAGCTATGACCATGATTACGCC" +
		"AAGCTCTAATACGACTCACTATAGGGAGAC"
	MIN_OVERLAP = 20
	EDIT = 2
)

// Generics comparae to  FindTwoVESBES function.
func FindOneVESBES(R1, R2, VES, output string) {
	//flag.Parse()
	//if *help {
	//	flag.Usage()
	//}
	wg.Add(1)
	go ReadPEFastq(jobChan, R1, R2)

	for i := 0; i<4; i++{
		wg.Add(1)
		go worker(jobChan, resultChan, VES, MIN_OVERLAP, EDIT)
	}
	out, _ := os.Create(output)
	defer out.Close()
	out_fasta := fasta.NewWriter(out,150)

	for {
		r  := <- resultChan
		if r.overlap{
			fmt.Println(r)
			r.Writer(out_fasta)
		}
	}
	wg.Wait()
}

// FindTwoVESBES function find forward and reverse VES-BES reads from Illumina Paried-end reads.
// The VES-BES reads will save in fastq format files.
func FindTwoVESBES(samplePath string){
	filePrefixRegexp := regexp.MustCompile(`SP[0-9]{2}-[0-9]{2}_.*-1.{1}`)
	filePrefix := filePrefixRegexp.FindStringSubmatch(samplePath)[0]
	sampeIDRegexp := regexp.MustCompile(`SP[0-9]{2}-[0-9]{2}`)
	sampleID := sampeIDRegexp.FindStringSubmatch(samplePath)[0]
	R1 := samplePath+"/"+filePrefix+"_1.clean.fq.gz"
	R2 := samplePath+"/"+filePrefix+"_2.clean.fq.gz"
	// Forwoard
	outputF := string(destinationDir)+"/VES-BES/"+sampleID+"R1_forward.fasta"
	FindOneVESBES(R1,R2, VESF, outputF)
	// Reverse
	outputR := string(destinationDir)+"/VES-BES/"+sampleID+"R1_reverse.fasta"
	FindOneVESBES(R1,R2, VESF, outputR)
}