package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"sync"
)

type BEDBase struct { // Basic BED format (Browser Extensible Data), only fist three columns.
	chr        string
	start, end int
}

type BEDsp struct { // Special BED format construction, including only 4 columns.
	BEDBase
	name string
}

func (b BEDsp) String() string {
	return fmt.Sprintf("%s\t%d\t%s\t%s", b.chr, b.start, b.end, b.name)
}

type FeatureSet struct {
	record []BEDsp
}

func (fs FeatureSet) String() string {
	s := strings.Builder{}
	s.WriteString(fmt.Sprintln("# Special BED format\n# chr\tstart\tend\tname"))
	for _, r := range fs.record {
		s.WriteString(fmt.Sprintf("%s\n", r))
	}
	return s.String()
}

func (fs FeatureSet) Write(file *os.File) {
	defer file.Close()
	file.WriteString(fs.String())
}

// ReadFeatureSet function implements how to automatically read records from bed format files into FeatureSet struct.
// path refers to the path of bed format file.
func ReadFeatureSet(path string) *FeatureSet {
	var FS = FeatureSet{record: make([]BEDsp, 0)}
	f, err := os.Open(path)
	checkFile(err, path)
	defer f.Close()
	scan := bufio.NewScanner(f)
	for scan.Scan() {
		next := scan.Text()
		if string(next[0]) != "#" {
			record := strings.Split(next, "\t")
			if len(record) == 4 {
				satrt, _ := strconv.ParseInt(record[1], 10, 64)
				end, _ := strconv.ParseInt(record[2], 10, 64)
				element := BEDsp{BEDBase{record[0], int(satrt), int(end)}, record[3]}
				FS.record = append(FS.record, element)
			} else {
				//log.Fatalln(path + "is not special BED format for BACtoPanda program")
				log.Println("new line\n" + next + "\n<<<<<<<<<<Look at, above!>>>>>>>>>>")
			}
		}
	}
	return &FS
}

type BEDWithFrequency struct {
	BEDsp
	// The score column in bed format specially refers to the frequency which each HindIII site occurs in sequencing reads.
	score int
}

func (bwf BEDWithFrequency) String() string {
	s := strings.Builder{}
	s.WriteString(fmt.Sprintf("%s\t%d\t%d\t%s\t%d", bwf.chr, bwf.start, bwf.end, bwf.name, bwf.score))
	return s.String()
}

type BEDWithFrequencySet struct {
	ele []BEDWithFrequency
}

func NewBEDWithFrequencySet() *BEDWithFrequencySet {
	return &BEDWithFrequencySet{ele: make([]BEDWithFrequency, 1000)}
}

func (bwfs BEDWithFrequencySet) String() string {
	s := strings.Builder{}
	for _, v := range bwfs.ele {
		s.WriteString(fmt.Sprintf("%s\n", v))
	}
	return s.String()
}

func (bwfs *BEDWithFrequencySet) Write(file *os.File) {
	file.WriteString(bwfs.String())
}

/*
	schedule：
		A: 把位点序列读入  pk
		B: 找到末端序列reads，并取末端序列 ok
		C: 通过末端序列找到位点，记录到字典中。map[string]BEDWithFrequency string = chr + start
*/

//var data = ReadFeatureSet("")

type BEDWithFrequencyMap struct {
	m map[string]*BEDWithFrequency
}

func NewBEDWithFrequencyMap() *BEDWithFrequencyMap {
	return &BEDWithFrequencyMap{
		m: make(map[string]*BEDWithFrequency, 1000),
	}
}

func (nbwfm *BEDWithFrequencyMap) ToBEDWithFrequency() *BEDWithFrequencySet {
	bwfs := NewBEDWithFrequencySet()
	for _, v := range nbwfm.m {
		bwfs.ele = append(bwfs.ele, *v)
	}
	return bwfs
}

var mt sync.Mutex

func (nbwfm *BEDWithFrequencyMap) update(set *FeatureSet, seq string) {
	m := nbwfm.m
	for _, v := range set.record {
		ga := NewGlobalAligner(v.name, seq)
		if ga.IsSimilar(4) {
			mt.Lock() // For concurrency security
			key := fmt.Sprintf("%s%d", v.chr, v.start)
			if ele, ok := m[key]; ok {
				ele.score += 1
			} else {
				ele := BEDWithFrequency{
					BEDsp{
						BEDBase{
							v.chr, v.start, v.end,
						},
						v.name},
					1}
				m[key] = &ele
			}
			mt.Unlock()
		}
	}
}

// run project
