package main

import "testing"

func TestRunBowtie2(t *testing.T) {
	runBowtie2("/mnt/raw_data/data_shenfujun/DNA/X101SC21083152-Z01-J001/2.cleandata/SP01-25_FDSW210295351-1r")
}
